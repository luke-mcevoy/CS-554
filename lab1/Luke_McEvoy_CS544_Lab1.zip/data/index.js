const postData = require('./posts');
const userData = require('./users');

module.exports = {
	users: userData,
	posts: postData,
};
